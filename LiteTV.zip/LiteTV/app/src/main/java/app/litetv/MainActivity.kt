package app.litetv

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.net.Uri
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var player: ExoPlayer
    private lateinit var panel: View
    private lateinit var list: ListView
    private lateinit var vpnBtn: Button
    private val names = ArrayList<String>()
    private val urls = ArrayList<String>()
    private var cur = -1

    private val backend by lazy { GoBackend(applicationContext) }
    private val tunnel = object : Tunnel {
        override fun getName() = "jp"
        override fun onStateChange(s: Tunnel.State) {
            runOnUiThread { vpnBtn.text = if (s == Tunnel.State.UP) "VPN: Japan ON" else "VPN: off" }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.main)
        panel = findViewById(R.id.panel)
        list = findViewById(R.id.channels)
        vpnBtn = findViewById(R.id.vpn)
        player = ExoPlayer.Builder(this).build()
        player.setVideoSurfaceView(findViewById<SurfaceView>(R.id.video))
        list.setOnItemClickListener { _, _, i, _ -> cur = i; play(urls[i]) }
        vpnBtn.setOnClickListener { toggleVpn() }
        findViewById<Button>(R.id.playlist).setOnClickListener { askUrl() }
        findViewById<Button>(R.id.file).setOnClickListener { pickFile() }
        val saved = getSharedPreferences("p", 0).getString("url", null)
        if (saved.isNullOrEmpty()) askUrl() else load(saved)
    }

    private fun play(u: String) {
        player.setMediaItem(MediaItem.fromUri(u))
        player.prepare()
        player.play()
        panel.visibility = View.GONE
    }

    private fun zap(d: Int) {
        if (urls.isEmpty()) return
        cur = (cur + d + urls.size) % urls.size
        play(urls[cur])
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (panel.visibility != View.VISIBLE) when (k) {
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_DPAD_CENTER -> {
                panel.visibility = View.VISIBLE; list.requestFocus(); return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(1); return true }
        }
        return super.onKeyDown(k, e)
    }

    private fun askUrl() {
        val prefs = getSharedPreferences("p", 0)
        val et = EditText(this)
        et.setSingleLine()
        et.hint = "http://example.com/playlist.m3u"
        et.setText(prefs.getString("url", "")?.takeIf { !it.startsWith("content:") })
        AlertDialog.Builder(this).setTitle("M3U playlist URL").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val s = et.text.toString().trim()
                prefs.edit().putString("url", s).apply()
                load(s)
            }.show()
    }

    // Parses #EXTINF / URL pairs. Runs through the VPN when it is on.
    private fun load(src: String) = thread {
        try {
            val n = ArrayList<String>()
            val u = ArrayList<String>()
            var name = ""
            readSrc(src).lines().forEach { l ->
                val t = l.trim()
                if (t.startsWith("#EXTINF")) name = t.substringAfterLast(',').trim()
                else if (t.isNotEmpty() && !t.startsWith("#")) {
                    n.add(name.ifEmpty { t }); u.add(t); name = ""
                }
            }
            runOnUiThread {
                names.clear(); names.addAll(n)
                urls.clear(); urls.addAll(u)
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
                list.requestFocus()
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Playlist failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    // Tunnels ONLY this app (IncludedApplications), so the rest of the TV is untouched.
    private fun toggleVpn() {
        VpnService.prepare(this)?.let { startActivityForResult(it, 1); return }
        thread {
            try {
                val on = backend.getState(tunnel) == Tunnel.State.UP
                val cfg = assets.open("jp.conf").bufferedReader().readText()
                    .replace("[Interface]", "[Interface]\nIncludedApplications = $packageName")
                backend.setState(
                    tunnel,
                    if (on) Tunnel.State.DOWN else Tunnel.State.UP,
                    Config.parse(cfg.byteInputStream())
                )
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "VPN: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        try {
            startActivityForResult(i, 2)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No file picker on this device - use a URL instead", Toast.LENGTH_LONG).show()
        }
    }

    private fun readSrc(s: String): String =
        if (s.startsWith("content:"))
            contentResolver.openInputStream(Uri.parse(s))!!.bufferedReader().use { it.readText() }
        else URL(s).readText()

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (c != RESULT_OK) return
        if (r == 1) toggleVpn()
        if (r == 2) d?.data?.let { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            getSharedPreferences("p", 0).edit().putString("url", uri.toString()).apply()
            load(uri.toString())
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
